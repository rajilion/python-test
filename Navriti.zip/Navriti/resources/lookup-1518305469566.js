(function(window, undefined) {
  var dictionary = {
    "2ffd71c1-c084-463c-984e-de523bb6e95f": "yesrejReviewIdeaDescription",
    "1eb48df0-28db-4e54-97e6-d575c2e06ed4": "ReviewIdeaDescription",
    "b15057df-fd2f-48fe-afee-4227d29402d5": "PanelDashBoard",
    "a97e34d9-023c-4035-accc-daf3be798be5": "FinalApproveIdeaDescription",
    "771dee08-6520-4b36-a842-1f1441cc5731": "PostAnIdeaAlert",
    "7d255b97-0b73-4f9c-9f33-53a2bb030b54": "ViewStatus",
    "c6aee186-e53f-4b59-92ca-956e91999a5b": "UserDashBoard",
    "d9f3ba9a-c72d-4cd5-b733-e4b9b1d0e3d0": "FinalReview",
    "0ca7eb85-07a6-4f9f-8125-67d01a88e16c": "YesinfoideaDescription",
    "23649682-bc9e-443c-affa-57ebc0d1950c": "InfoIdeaDescription",
    "316a1198-4743-4eed-9ce2-f727757620df": "yesapprovedReviewIdeaDescription",
    "83723007-3000-480a-a461-5f953b9eeb02": "YesApproveIdeaDescription",
    "500c2ad0-3ad1-4fa0-a2ca-2162a891f9d7": "ReadyTrackIdeas",
    "748fbfc3-5f70-488c-96b0-cd7f6714d5e3": "PanelHistory",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Login",
    "c7b95ba5-9e6d-416b-94a9-23b9b16c4f2a": "RejectIdeaDescription",
    "a292679a-e87f-4b7c-9112-86856f8fa2ef": "ApproveIdeaDescription",
    "273eed83-a84f-4fab-ad21-3915a8c8d59c": "TrackIdeas",
    "5e757252-7da1-4bf2-a679-6fa872e9a69a": "ReviewDashBoard",
    "52901887-08e3-41c4-9020-1251d924d195": "PostAnIdea",
    "e018d804-7891-418b-a400-691f2b612e2c": "yesinfReviewIdeaDescription",
    "f3b187f7-58cf-49a9-aefc-c5f6dc62d561": "approveReviewIdeaDescription",
    "547f90ef-0156-4d44-9a8d-d5d89a9d45b6": "IdeaDescription",
    "8a1be618-e706-4ddb-becc-46fe8188effb": "rejectReviewIdeaDescription",
    "490446c4-5889-448e-bbf1-00a6e543edb1": "YesReadyTrackIdeas",
    "023113a7-79fb-49d5-870a-fec1ec1d02ab": "Review",
    "d79173ae-b7d5-4fc3-9a11-fd38482496f2": "EditPostAnIdea",
    "07f919e2-2727-47a4-a2a3-ecc090ac7f42": "UserHistory",
    "458e7738-4ea0-465a-b2cb-fa2cadbdfbe6": "wrongLogin",
    "b3fe0f51-fcb4-45db-afac-68f83e4ca960": "infoReviewIdeaDescription",
    "515ee10b-0558-4276-a75c-dd7da5623870": "YesRejectIdeaDescription",
    "e73b655d-d3ec-4dcc-a55c-6e0293422bde": "960 grid - 16 columns",
    "ef07b413-721c-418e-81b1-33a7ed533245": "960 grid - 12 columns",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);