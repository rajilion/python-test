(function(window, undefined) {

  var jimLinks = {
    "2ffd71c1-c084-463c-984e-de523bb6e95f" : {
      "Button_1" : [
        "a292679a-e87f-4b7c-9112-86856f8fa2ef",
        "f3b187f7-58cf-49a9-aefc-c5f6dc62d561"
      ],
      "Button_2" : [
        "c7b95ba5-9e6d-416b-94a9-23b9b16c4f2a"
      ],
      "Button_3" : [
        "23649682-bc9e-443c-affa-57ebc0d1950c"
      ],
      "Button_4" : [
        "d9f3ba9a-c72d-4cd5-b733-e4b9b1d0e3d0"
      ],
      "Button_5" : [
        "023113a7-79fb-49d5-870a-fec1ec1d02ab",
        "d9f3ba9a-c72d-4cd5-b733-e4b9b1d0e3d0"
      ]
    },
    "1eb48df0-28db-4e54-97e6-d575c2e06ed4" : {
      "Button_1" : [
        "a292679a-e87f-4b7c-9112-86856f8fa2ef",
        "f3b187f7-58cf-49a9-aefc-c5f6dc62d561"
      ],
      "Button_2" : [
        "8a1be618-e706-4ddb-becc-46fe8188effb"
      ],
      "Button_3" : [
        "b3fe0f51-fcb4-45db-afac-68f83e4ca960"
      ],
      "Button_4" : [
        "d9f3ba9a-c72d-4cd5-b733-e4b9b1d0e3d0"
      ]
    },
    "b15057df-fd2f-48fe-afee-4227d29402d5" : {
      "Button_1" : [
        "023113a7-79fb-49d5-870a-fec1ec1d02ab"
      ],
      "Button_2" : [
        "748fbfc3-5f70-488c-96b0-cd7f6714d5e3"
      ],
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "a97e34d9-023c-4035-accc-daf3be798be5" : {
      "Button_4" : [
        "023113a7-79fb-49d5-870a-fec1ec1d02ab"
      ],
      "Button_5" : [
        "83723007-3000-480a-a461-5f953b9eeb02"
      ],
      "Button_6" : [
        "1eb48df0-28db-4e54-97e6-d575c2e06ed4"
      ]
    },
    "771dee08-6520-4b36-a842-1f1441cc5731" : {
      "Button_1" : [
        "c6aee186-e53f-4b59-92ca-956e91999a5b"
      ]
    },
    "7d255b97-0b73-4f9c-9f33-53a2bb030b54" : {
      "Button_1" : [
        "273eed83-a84f-4fab-ad21-3915a8c8d59c"
      ]
    },
    "c6aee186-e53f-4b59-92ca-956e91999a5b" : {
      "Button_1" : [
        "52901887-08e3-41c4-9020-1251d924d195"
      ],
      "Button_2" : [
        "273eed83-a84f-4fab-ad21-3915a8c8d59c"
      ],
      "Button_3" : [
        "07f919e2-2727-47a4-a2a3-ecc090ac7f42"
      ],
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d9f3ba9a-c72d-4cd5-b733-e4b9b1d0e3d0" : {
      "Button_5" : [
        "5e757252-7da1-4bf2-a679-6fa872e9a69a"
      ],
      "Button_2" : [
        "1eb48df0-28db-4e54-97e6-d575c2e06ed4"
      ],
      "Button_4" : [
        "1eb48df0-28db-4e54-97e6-d575c2e06ed4"
      ]
    },
    "0ca7eb85-07a6-4f9f-8125-67d01a88e16c" : {
      "Button_4" : [
        "023113a7-79fb-49d5-870a-fec1ec1d02ab"
      ],
      "Button_5" : [
        "023113a7-79fb-49d5-870a-fec1ec1d02ab",
        "d9f3ba9a-c72d-4cd5-b733-e4b9b1d0e3d0"
      ]
    },
    "23649682-bc9e-443c-affa-57ebc0d1950c" : {
      "Button_4" : [
        "023113a7-79fb-49d5-870a-fec1ec1d02ab"
      ],
      "Button_5" : [
        "0ca7eb85-07a6-4f9f-8125-67d01a88e16c"
      ],
      "Button_6" : [
        "547f90ef-0156-4d44-9a8d-d5d89a9d45b6",
        "1eb48df0-28db-4e54-97e6-d575c2e06ed4"
      ]
    },
    "316a1198-4743-4eed-9ce2-f727757620df" : {
      "Button_1" : [
        "a292679a-e87f-4b7c-9112-86856f8fa2ef",
        "f3b187f7-58cf-49a9-aefc-c5f6dc62d561"
      ],
      "Button_2" : [
        "c7b95ba5-9e6d-416b-94a9-23b9b16c4f2a"
      ],
      "Button_3" : [
        "23649682-bc9e-443c-affa-57ebc0d1950c"
      ],
      "Button_4" : [
        "d9f3ba9a-c72d-4cd5-b733-e4b9b1d0e3d0"
      ],
      "Button_5" : [
        "023113a7-79fb-49d5-870a-fec1ec1d02ab",
        "d9f3ba9a-c72d-4cd5-b733-e4b9b1d0e3d0"
      ]
    },
    "83723007-3000-480a-a461-5f953b9eeb02" : {
      "Button_4" : [
        "023113a7-79fb-49d5-870a-fec1ec1d02ab"
      ],
      "Button_5" : [
        "023113a7-79fb-49d5-870a-fec1ec1d02ab",
        "d9f3ba9a-c72d-4cd5-b733-e4b9b1d0e3d0"
      ]
    },
    "500c2ad0-3ad1-4fa0-a2ca-2162a891f9d7" : {
      "Button_1" : [
        "7d255b97-0b73-4f9c-9f33-53a2bb030b54"
      ],
      "Button_3" : [
        "7d255b97-0b73-4f9c-9f33-53a2bb030b54"
      ],
      "Button_4" : [
        "d79173ae-b7d5-4fc3-9a11-fd38482496f2"
      ],
      "Button_5" : [
        "c6aee186-e53f-4b59-92ca-956e91999a5b"
      ],
      "Button_6" : [
        "7d255b97-0b73-4f9c-9f33-53a2bb030b54"
      ],
      "Button_7" : [
        "7d255b97-0b73-4f9c-9f33-53a2bb030b54"
      ],
      "Button_8" : [
        "490446c4-5889-448e-bbf1-00a6e543edb1"
      ],
      "Button_9" : [
        "273eed83-a84f-4fab-ad21-3915a8c8d59c"
      ]
    },
    "748fbfc3-5f70-488c-96b0-cd7f6714d5e3" : {
      "Button_2" : [
        "b15057df-fd2f-48fe-afee-4227d29402d5"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "c6aee186-e53f-4b59-92ca-956e91999a5b",
        "b15057df-fd2f-48fe-afee-4227d29402d5",
        "458e7738-4ea0-465a-b2cb-fa2cadbdfbe6",
        "5e757252-7da1-4bf2-a679-6fa872e9a69a"
      ]
    },
    "c7b95ba5-9e6d-416b-94a9-23b9b16c4f2a" : {
      "Button_4" : [
        "023113a7-79fb-49d5-870a-fec1ec1d02ab"
      ],
      "Button_5" : [
        "515ee10b-0558-4276-a75c-dd7da5623870"
      ],
      "Button_6" : [
        "547f90ef-0156-4d44-9a8d-d5d89a9d45b6",
        "1eb48df0-28db-4e54-97e6-d575c2e06ed4"
      ]
    },
    "a292679a-e87f-4b7c-9112-86856f8fa2ef" : {
      "Button_4" : [
        "023113a7-79fb-49d5-870a-fec1ec1d02ab"
      ],
      "Button_5" : [
        "83723007-3000-480a-a461-5f953b9eeb02"
      ],
      "Button_6" : [
        "547f90ef-0156-4d44-9a8d-d5d89a9d45b6"
      ]
    },
    "273eed83-a84f-4fab-ad21-3915a8c8d59c" : {
      "Button_1" : [
        "7d255b97-0b73-4f9c-9f33-53a2bb030b54"
      ],
      "Button_3" : [
        "7d255b97-0b73-4f9c-9f33-53a2bb030b54"
      ],
      "Button_4" : [
        "d79173ae-b7d5-4fc3-9a11-fd38482496f2"
      ],
      "Button_5" : [
        "c6aee186-e53f-4b59-92ca-956e91999a5b"
      ],
      "Button_6" : [
        "500c2ad0-3ad1-4fa0-a2ca-2162a891f9d7"
      ],
      "Button_7" : [
        "500c2ad0-3ad1-4fa0-a2ca-2162a891f9d7"
      ]
    },
    "5e757252-7da1-4bf2-a679-6fa872e9a69a" : {
      "Button_1" : [
        "d9f3ba9a-c72d-4cd5-b733-e4b9b1d0e3d0"
      ],
      "Button_2" : [
        "748fbfc3-5f70-488c-96b0-cd7f6714d5e3"
      ],
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "52901887-08e3-41c4-9020-1251d924d195" : {
      "Button_7" : [
        "771dee08-6520-4b36-a842-1f1441cc5731"
      ],
      "Button_8" : [
        "c6aee186-e53f-4b59-92ca-956e91999a5b"
      ]
    },
    "e018d804-7891-418b-a400-691f2b612e2c" : {
      "Button_1" : [
        "a292679a-e87f-4b7c-9112-86856f8fa2ef",
        "f3b187f7-58cf-49a9-aefc-c5f6dc62d561"
      ],
      "Button_2" : [
        "8a1be618-e706-4ddb-becc-46fe8188effb"
      ],
      "Button_3" : [
        "23649682-bc9e-443c-affa-57ebc0d1950c"
      ],
      "Button_4" : [
        "d9f3ba9a-c72d-4cd5-b733-e4b9b1d0e3d0"
      ],
      "Button_5" : [
        "023113a7-79fb-49d5-870a-fec1ec1d02ab",
        "d9f3ba9a-c72d-4cd5-b733-e4b9b1d0e3d0"
      ]
    },
    "f3b187f7-58cf-49a9-aefc-c5f6dc62d561" : {
      "Button_1" : [
        "a292679a-e87f-4b7c-9112-86856f8fa2ef",
        "a97e34d9-023c-4035-accc-daf3be798be5"
      ],
      "Button_2" : [
        "c7b95ba5-9e6d-416b-94a9-23b9b16c4f2a"
      ],
      "Button_3" : [
        "23649682-bc9e-443c-affa-57ebc0d1950c"
      ],
      "Button_4" : [
        "d9f3ba9a-c72d-4cd5-b733-e4b9b1d0e3d0"
      ],
      "Button_5" : [
        "316a1198-4743-4eed-9ce2-f727757620df"
      ],
      "Button_6" : [
        "1eb48df0-28db-4e54-97e6-d575c2e06ed4"
      ]
    },
    "547f90ef-0156-4d44-9a8d-d5d89a9d45b6" : {
      "Button_1" : [
        "a292679a-e87f-4b7c-9112-86856f8fa2ef"
      ],
      "Button_2" : [
        "c7b95ba5-9e6d-416b-94a9-23b9b16c4f2a"
      ],
      "Button_3" : [
        "23649682-bc9e-443c-affa-57ebc0d1950c"
      ],
      "Button_4" : [
        "023113a7-79fb-49d5-870a-fec1ec1d02ab"
      ]
    },
    "8a1be618-e706-4ddb-becc-46fe8188effb" : {
      "Button_1" : [
        "a292679a-e87f-4b7c-9112-86856f8fa2ef",
        "f3b187f7-58cf-49a9-aefc-c5f6dc62d561"
      ],
      "Button_2" : [
        "c7b95ba5-9e6d-416b-94a9-23b9b16c4f2a"
      ],
      "Button_3" : [
        "23649682-bc9e-443c-affa-57ebc0d1950c"
      ],
      "Button_4" : [
        "d9f3ba9a-c72d-4cd5-b733-e4b9b1d0e3d0"
      ],
      "Button_5" : [
        "2ffd71c1-c084-463c-984e-de523bb6e95f"
      ],
      "Button_6" : [
        "547f90ef-0156-4d44-9a8d-d5d89a9d45b6",
        "1eb48df0-28db-4e54-97e6-d575c2e06ed4"
      ]
    },
    "490446c4-5889-448e-bbf1-00a6e543edb1" : {
      "Button_1" : [
        "7d255b97-0b73-4f9c-9f33-53a2bb030b54"
      ],
      "Button_3" : [
        "7d255b97-0b73-4f9c-9f33-53a2bb030b54"
      ],
      "Button_4" : [
        "d79173ae-b7d5-4fc3-9a11-fd38482496f2"
      ],
      "Button_5" : [
        "c6aee186-e53f-4b59-92ca-956e91999a5b"
      ],
      "Button_6" : [
        "7d255b97-0b73-4f9c-9f33-53a2bb030b54"
      ],
      "Button_7" : [
        "7d255b97-0b73-4f9c-9f33-53a2bb030b54"
      ],
      "Button_8" : [
        "273eed83-a84f-4fab-ad21-3915a8c8d59c"
      ]
    },
    "023113a7-79fb-49d5-870a-fec1ec1d02ab" : {
      "Button_1" : [
        "547f90ef-0156-4d44-9a8d-d5d89a9d45b6"
      ],
      "Button_3" : [
        "547f90ef-0156-4d44-9a8d-d5d89a9d45b6"
      ],
      "Button_5" : [
        "b15057df-fd2f-48fe-afee-4227d29402d5"
      ]
    },
    "d79173ae-b7d5-4fc3-9a11-fd38482496f2" : {
      "Button_7" : [
        "771dee08-6520-4b36-a842-1f1441cc5731"
      ],
      "Button_8" : [
        "c6aee186-e53f-4b59-92ca-956e91999a5b"
      ]
    },
    "07f919e2-2727-47a4-a2a3-ecc090ac7f42" : {
      "Button_1" : [
        "c6aee186-e53f-4b59-92ca-956e91999a5b"
      ]
    },
    "458e7738-4ea0-465a-b2cb-fa2cadbdfbe6" : {
      "Button_1" : [
        "c6aee186-e53f-4b59-92ca-956e91999a5b",
        "b15057df-fd2f-48fe-afee-4227d29402d5",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "b3fe0f51-fcb4-45db-afac-68f83e4ca960" : {
      "Button_1" : [
        "a292679a-e87f-4b7c-9112-86856f8fa2ef",
        "f3b187f7-58cf-49a9-aefc-c5f6dc62d561"
      ],
      "Button_2" : [
        "8a1be618-e706-4ddb-becc-46fe8188effb"
      ],
      "Button_3" : [
        "23649682-bc9e-443c-affa-57ebc0d1950c"
      ],
      "Button_4" : [
        "d9f3ba9a-c72d-4cd5-b733-e4b9b1d0e3d0"
      ],
      "Button_5" : [
        "e018d804-7891-418b-a400-691f2b612e2c"
      ],
      "Button_6" : [
        "547f90ef-0156-4d44-9a8d-d5d89a9d45b6",
        "1eb48df0-28db-4e54-97e6-d575c2e06ed4"
      ]
    },
    "515ee10b-0558-4276-a75c-dd7da5623870" : {
      "Button_4" : [
        "023113a7-79fb-49d5-870a-fec1ec1d02ab"
      ],
      "Button_5" : [
        "023113a7-79fb-49d5-870a-fec1ec1d02ab",
        "d9f3ba9a-c72d-4cd5-b733-e4b9b1d0e3d0"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);